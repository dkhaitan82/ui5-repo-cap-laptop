sap.ui.define([
   "sap/ui/core/mvc/Controller",
   "sap/m/MessageToast",
   "sap/ui/model/json/JSONModel",
   "sap/ui/model/odata/ODataModel"
], function(Controller, MessageToast, JSONModel, ODataModel) {
	"use strict";
	return Controller.extend("burberry.hana.util.controller.App", {
	    // ============================================================
		// Initialize (Use this file as template while creating new Controller)                          
		// ============================================================
		onInit: function() {
           
            
		}
	});
});